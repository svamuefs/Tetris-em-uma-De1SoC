A simple program that prints "Hello World!" to the terminal. Compile using the following command:

  gcc helloworld.c -o helloworld

Execute using:

  ./helloworld
